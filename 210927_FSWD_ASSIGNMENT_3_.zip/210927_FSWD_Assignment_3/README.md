Basic React portfolio application.
